import React from 'react'

const ManageArrangement = () => {
  return (
    <div>
       coming soon
    </div>
  )
}

export default ManageArrangement
