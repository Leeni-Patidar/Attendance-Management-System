import React from 'react'

const DownloadReport = () => {
  return (
    <div>
       coming soon
    </div>
  )
}

export default DownloadReport
