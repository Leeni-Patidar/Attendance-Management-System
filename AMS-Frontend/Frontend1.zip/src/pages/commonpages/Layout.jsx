import React from 'react'

const Layout = () => {
  return (
    <div>
      
    </div>
  )
}

export default Layout
